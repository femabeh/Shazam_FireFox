function search() {

}

document.getElementById("search").addEventListener('click', search);